#ifndef CRC_H
#define CRC_H

void crc32(const void* data, size_t n_bytes, uint32_t* crc);

#endif /* CRC_H */
